# ICADS 2025 Conference Website

## Current State
New project with empty React/TypeScript frontend and scaffolded Motoko backend.

## Requested Changes (Diff)

### Add
- Full ICADS 2025 conference website as a React SPA
- Sticky navigation bar with mobile hamburger menu
- Ticker/marquee announcement bar
- Hero image slideshow with auto-advance and dot/arrow controls
- Marquee scrolling image strip
- Stats counter strip (students, publications, faculty, placement rate)
- Director/Conference Chair message section
- Conference Committee grid (photo, name, role, institution)
- Important Dates timeline list
- Keynote Speakers grid
- Workshops grid
- Paper Submission section (topics, formatting, steps, EasyChair CTA)
- Special Sessions grid
- Registration fees table (categories, early bird, regular, student)
- Sponsorship tiers (Gold/Silver/Bronze) and sponsors grid
- Contact section (address, phone, email, social, map placeholder)
- Footer with links grid
- Scroll-to-top FAB button
- Scroll-reveal animations on sections
- Animated stats counter on scroll
- Color scheme: maroon (#8b0000) and gold (#ffcc00)

### Modify
- index.css: add custom global styles for maroon/gold theme
- App.tsx: replace default content with the conference website

### Remove
- Default Caffeine placeholder content

## Implementation Plan
1. Create App.tsx with all sections as React components
2. Add CSS custom properties and animation styles in index.css
3. Use Unsplash images for hero slides and marquee
4. Use randomuser.me for placeholder portraits
5. Implement scroll-reveal via IntersectionObserver
6. Implement animated stats counter
7. Implement hero slideshow with auto-advance
8. Implement sticky nav with active section highlighting
9. No backend calls needed — all data is static
