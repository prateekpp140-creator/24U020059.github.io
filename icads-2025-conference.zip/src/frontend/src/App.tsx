import { useCallback, useEffect, useRef, useState } from "react";

// ─── DATA ────────────────────────────────────────────────────────────────────

const MARQUEE_IMAGES = [
  {
    url: "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=80",
    label: "Admissions Open 2025",
  },
  {
    url: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=800&q=80",
    label: "Convocation Ceremony 2025",
  },
  {
    url: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80",
    label: "Academic Excellence",
  },
  {
    url: "https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?auto=format&fit=crop&w=800&q=80",
    label: "Institute of National Importance",
  },
  {
    url: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80",
    label: "Campus Events",
  },
  {
    url: "https://images.unsplash.com/photo-1532094349884-543559059340?auto=format&fit=crop&w=800&q=80",
    label: "Advanced Laboratories",
  },
];

const HERO_SLIDES = [
  {
    url: "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1600&q=80",
    tag: "ICADS 2025",
    title: "International Conference on AI & Data Science",
    subtitle: "IIIT Bhopal, India · September 15–17, 2025",
  },
  {
    url: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=1600&q=80",
    tag: "Call for Papers",
    title: "Submit Your Research Now",
    subtitle: "AI, ML, Data Science, NLP, Computer Vision and more",
  },
  {
    url: "https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?auto=format&fit=crop&w=1600&q=80",
    tag: "Campus",
    title: "State-of-the-Art IIIT Bhopal Campus",
    subtitle: "An Institute of National Importance — MANIT Campus, Bhopal",
  },
  {
    url: "https://images.unsplash.com/photo-1532094349884-543559059340?auto=format&fit=crop&w=1600&q=80",
    tag: "Research",
    title: "Advanced Research Facilities",
    subtitle: "World-class laboratories driving innovation",
  },
  {
    url: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=80",
    tag: "Student Life",
    title: "Vibrant Campus Culture",
    subtitle: "Clubs, hackathons, cultural fests and international events",
  },
  {
    url: "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80",
    tag: "Placements",
    title: "Excellent Placement Record",
    subtitle: "Top recruiters: Amazon, Microsoft, Adobe, NVIDIA & more",
  },
];

const COMMITTEE = [
  {
    name: "Dr. Ashutosh K. Singh",
    role: "General Chair",
    inst: "IIIT Bhopal",
    photo: "https://randomuser.me/api/portraits/men/75.jpg",
  },
  {
    name: "Dr. Priya Sharma",
    role: "Program Chair",
    inst: "IIT Delhi",
    photo: "https://randomuser.me/api/portraits/women/44.jpg",
  },
  {
    name: "Dr. Rahul Verma",
    role: "Technical Chair",
    inst: "IIT Bombay",
    photo: "https://randomuser.me/api/portraits/men/32.jpg",
  },
  {
    name: "Dr. Sunita Patel",
    role: "Publicity Chair",
    inst: "NIT Bhopal",
    photo: "https://randomuser.me/api/portraits/women/68.jpg",
  },
  {
    name: "Dr. Amit Gupta",
    role: "Finance Chair",
    inst: "IIIT Bhopal",
    photo: "https://randomuser.me/api/portraits/men/54.jpg",
  },
  {
    name: "Dr. Neha Joshi",
    role: "Workshop Chair",
    inst: "IIT Indore",
    photo: "https://randomuser.me/api/portraits/women/29.jpg",
  },
];

const DATES = [
  { date: "15 March 2025", event: "Paper Submission Portal Opens", icon: "📋" },
  { date: "30 May 2025", event: "Paper Submission Deadline", icon: "⚡" },
  { date: "20 June 2025", event: "Notification of Acceptance", icon: "📧" },
  { date: "10 July 2025", event: "Camera-Ready Paper Deadline", icon: "📄" },
  {
    date: "31 July 2025",
    event: "Early-Bird Registration Deadline",
    icon: "🏷️",
  },
  { date: "1 August 2025", event: "Registration Deadline", icon: "✅" },
  { date: "15–17 September 2025", event: "Conference Dates", icon: "🎓" },
];

const SPEAKERS = [
  {
    name: "Prof. Andrew Ng",
    inst: "Stanford University",
    talk: "The Future of AI in Education and Research",
    photo: "https://randomuser.me/api/portraits/men/10.jpg",
  },
  {
    name: "Dr. Fei-Fei Li",
    inst: "Google Cloud AI",
    talk: "Human-Centered AI and the Path Forward",
    photo: "https://randomuser.me/api/portraits/women/10.jpg",
  },
  {
    name: "Prof. Yoshua Bengio",
    inst: "Université de Montréal",
    talk: "Deep Learning: Past, Present and Future",
    photo: "https://randomuser.me/api/portraits/men/22.jpg",
  },
  {
    name: "Dr. Sanjeev Arora",
    inst: "Princeton University",
    talk: "Theoretical Foundations of Modern ML",
    photo: "https://randomuser.me/api/portraits/men/36.jpg",
  },
];

const WORKSHOPS = [
  {
    title: "Deep Learning with PyTorch",
    desc: "Hands-on workshop covering CNN, RNN, Transformers and practical model deployment.",
    date: "13 Sept 2025",
    dur: "Full Day",
  },
  {
    title: "NLP & Large Language Models",
    desc: "Explore BERT, GPT, fine-tuning techniques and responsible LLM deployment.",
    date: "13 Sept 2025",
    dur: "Full Day",
  },
  {
    title: "Explainable AI (XAI)",
    desc: "LIME, SHAP, GradCAM and other interpretability frameworks.",
    date: "14 Sept 2025",
    dur: "Half Day AM",
  },
  {
    title: "Edge AI & IoT Applications",
    desc: "Deploy AI on resource-constrained devices using TensorFlow Lite & Raspberry Pi.",
    date: "15 Sept 2025",
    dur: "Full Day",
  },
];

const TOPICS = [
  "Machine Learning & Deep Learning",
  "Natural Language Processing",
  "Computer Vision",
  "Reinforcement Learning",
  "Federated & Privacy-preserving AI",
  "AI in Healthcare",
  "Knowledge Graphs & Reasoning",
  "Explainable AI (XAI)",
  "Edge Computing & IoT",
  "Data Mining & Big Data Analytics",
];

const SPECIALS = [
  {
    icon: "🧠",
    title: "AI in Healthcare & Biomedical Systems",
    desc: "Diagnosis, drug discovery, patient monitoring and clinical decision support.",
  },
  {
    icon: "🌍",
    title: "AI for Climate & Sustainability",
    desc: "Environmental monitoring, climate modelling, and smart energy management.",
  },
  {
    icon: "🔒",
    title: "Cybersecurity & Adversarial AI",
    desc: "Adversarial attacks, intrusion detection, and privacy-preserving ML.",
  },
  {
    icon: "🏙️",
    title: "Smart Cities & Urban Computing",
    desc: "Traffic optimisation, intelligent transportation and urban planning with AI.",
  },
];

const TIERS = [
  {
    tier: "Gold",
    price: "₹5,00,000",
    color: "#BFA14A",
    benefits: [
      "Logo on all materials",
      "Exhibition booth",
      "5 complimentary registrations",
      "Keynote sponsorship slot",
    ],
  },
  {
    tier: "Silver",
    price: "₹3,00,000",
    color: "#A0A0A0",
    benefits: [
      "Logo on website & proceedings",
      "Exhibition booth",
      "3 complimentary registrations",
    ],
  },
  {
    tier: "Bronze",
    price: "₹1,50,000",
    color: "#C8956C",
    benefits: [
      "Logo on website",
      "1 complimentary registration",
      "Acknowledgment in programme",
    ],
  },
];

const SPONSORS = [
  "Amazon",
  "Microsoft",
  "NVIDIA",
  "TCS",
  "Adobe",
  "Qualcomm",
  "Flipkart",
  "Atlassian",
  "Infosys",
  "Wipro",
  "Google",
  "IBM",
  "Deloitte",
  "Accenture",
];

const NAV_SECTIONS = [
  { id: "home", label: "Home" },
  { id: "committee", label: "Committee" },
  { id: "important-dates", label: "Important Dates" },
  { id: "speakers", label: "Speakers" },
  { id: "workshop", label: "Workshop" },
  { id: "submission", label: "Submission" },
  { id: "special-session", label: "Special Session" },
  { id: "registration", label: "Registration" },
  { id: "sponsorship", label: "Sponsorship" },
  { id: "contact", label: "Contact" },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("revealed");
            observer.unobserve(e.target);
          }
        }
      },
      { threshold: 0.07 },
    );
    const els = document.querySelectorAll(".reveal");
    for (const el of els) observer.observe(el);
    return () => observer.disconnect();
  }, []);
}

function useActiveSection() {
  const [activeId, setActiveId] = useState("home");
  useEffect(() => {
    const handler = () => {
      let cur = "home";
      for (const s of NAV_SECTIONS) {
        const el = document.getElementById(s.id);
        if (el && window.scrollY >= el.offsetTop - 140) {
          cur = s.id;
        }
      }
      setActiveId(cur);
    };
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);
  return activeId;
}

function useScrollTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const handler = () => setShow(window.scrollY > 300);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);
  return show;
}

function useStatsCounter() {
  const triggered = useRef(false);
  useEffect(() => {
    const statsEl = document.getElementById("stats-strip");
    if (!statsEl) return;
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting && !triggered.current) {
            triggered.current = true;
            const statEls =
              document.querySelectorAll<HTMLElement>(".stat-number");
            for (const el of statEls) {
              const target = Number.parseInt(el.dataset.target ?? "0", 10);
              const suffix = el.dataset.suffix ?? "";
              let v = 0;
              const step = target / 80;
              const t = setInterval(() => {
                v += step;
                if (v >= target) {
                  v = target;
                  clearInterval(t);
                }
                el.textContent = Math.ceil(v) + suffix;
              }, 18);
            }
          }
        }
      },
      { threshold: 0.3 },
    );
    observer.observe(statsEl);
    return () => observer.disconnect();
  }, []);
}

function scrollTo(id: string) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: "smooth" });
}

// ─── SECTION WRAPPER ─────────────────────────────────────────────────────────

interface SectionProps {
  id?: string;
  light?: boolean;
  children: React.ReactNode;
  className?: string;
}

function Section({
  id,
  light = false,
  children,
  className = "",
}: SectionProps) {
  return (
    <section
      id={id}
      className={`py-16 px-4 ${light ? "" : "bg-white"} ${className}`}
      style={
        light
          ? { backgroundColor: "var(--page-bg)" }
          : { backgroundColor: "white" }
      }
    >
      {children}
    </section>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span
      style={{ color: "var(--gold)" }}
      className="block text-center text-[0.68rem] font-bold tracking-widest uppercase mb-1"
    >
      {children}
    </span>
  );
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2
      className="text-3xl font-extrabold text-center mb-10 section-heading-line"
      style={{ color: "var(--maroon)" }}
    >
      {children}
    </h2>
  );
}

// ─── INSTITUTE HEADER ────────────────────────────────────────────────────────

function InstituteHeader() {
  return (
    <header
      style={{ borderBottom: "3px solid var(--maroon)" }}
      className="flex items-center gap-3 px-4 py-3 bg-white"
    >
      {/* Logo circle */}
      <div
        style={{
          width: 60,
          height: 60,
          flexShrink: 0,
          borderRadius: "50%",
          background: "var(--maroon)",
          border: "3px solid var(--gold)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          fontWeight: 700,
          fontSize: "0.7rem",
          lineHeight: 1.25,
          textAlign: "center",
        }}
      >
        IIIT
        <br />
        BPL
      </div>
      {/* Institute info */}
      <div className="flex-1 text-center">
        <p
          className="text-[0.78rem] font-medium"
          style={{ color: "var(--maroon)" }}
        >
          भारतीय सूचना प्रौद्योगिकी संस्थान, भोपाल
        </p>
        <h1
          className="text-[0.92rem] font-extrabold uppercase"
          style={{ color: "var(--maroon)" }}
        >
          Indian Institute of Information Technology, Bhopal
        </h1>
        <p className="text-[0.68rem]" style={{ color: "var(--text-light)" }}>
          (An Institute of National Importance)
        </p>
      </div>
      {/* ICADS 2025 badge */}
      <div className="hidden sm:block text-right flex-shrink-0">
        <p
          className="font-extrabold text-lg leading-none"
          style={{ color: "var(--maroon)" }}
        >
          ICADS
        </p>
        <p
          className="font-extrabold text-lg leading-none"
          style={{ color: "var(--gold)" }}
        >
          2025
        </p>
      </div>
    </header>
  );
}

// ─── TICKER ──────────────────────────────────────────────────────────────────

function TickerBar() {
  const msg =
    "📢 Admissions 2025 Open\u00a0|\u00a0 📄 Research Proposals Invited\u00a0|\u00a0 🎓 PhD Applications Closing Soon\u00a0|\u00a0 📅 ICADS 2025 — International Conference on AI & Data Science\u00a0|\u00a0 🏆 Paper Submission Deadline: 30 May 2025\u00a0|\u00a0 ";
  return (
    <div
      className="overflow-hidden py-1.5 text-sm font-medium text-white"
      style={{ backgroundColor: "var(--maroon-mid)" }}
    >
      <div className="ticker-inner">
        <span className="pr-8">{msg}</span>
        <span className="pr-8">{msg}</span>
      </div>
    </div>
  );
}

// ─── STICKY NAV ──────────────────────────────────────────────────────────────

function StickyNav({ activeId }: { activeId: string }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = useCallback((id: string) => {
    scrollTo(id);
    setMobileOpen(false);
  }, []);

  return (
    <nav
      className="sticky top-0 z-50"
      style={{
        backgroundColor: "var(--maroon)",
        boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
      }}
    >
      <div className="max-w-[1200px] mx-auto px-3 flex items-center justify-between">
        {/* Desktop nav */}
        <div className="hidden md:flex flex-wrap items-center flex-1 justify-center">
          {NAV_SECTIONS.map((s) => (
            <button
              type="button"
              key={s.id}
              className={`icads-nav-link ${activeId === s.id ? "active" : ""}`}
              onClick={() => handleNav(s.id)}
              data-ocid={`nav.${s.id}.link`}
            >
              {s.label}
            </button>
          ))}
        </div>
        {/* Register Now button */}
        <button
          type="button"
          className="hidden md:block btn-register ml-2"
          onClick={() => alert("Registration portal coming soon!")}
          data-ocid="nav.register.button"
        >
          Register Now
        </button>
        {/* Mobile toggle */}
        <button
          type="button"
          className="md:hidden p-3 text-white text-xl font-bold bg-transparent border-0"
          onClick={() => setMobileOpen((o) => !o)}
          aria-label="Toggle menu"
          data-ocid="nav.menu.toggle"
        >
          {mobileOpen ? "✕" : "☰"}
        </button>
      </div>
      {/* Mobile drawer */}
      {mobileOpen && (
        <div
          className="md:hidden flex flex-col"
          style={{ backgroundColor: "var(--maroon)" }}
        >
          {NAV_SECTIONS.map((s) => (
            <button
              type="button"
              key={s.id}
              className={`icads-nav-link ${activeId === s.id ? "active" : ""}`}
              onClick={() => handleNav(s.id)}
              data-ocid={`nav.mobile.${s.id}.link`}
            >
              {s.label}
            </button>
          ))}
          <button
            type="button"
            className="btn-gold mx-4 my-3"
            onClick={() => {
              alert("Registration portal coming soon!");
              setMobileOpen(false);
            }}
            data-ocid="nav.mobile.register.button"
          >
            Register Now
          </button>
        </div>
      )}
    </nav>
  );
}

// ─── MARQUEE IMAGE STRIP ─────────────────────────────────────────────────────

function MarqueeStrip() {
  const doubled = [...MARQUEE_IMAGES, ...MARQUEE_IMAGES];
  return (
    <div
      className="overflow-hidden py-3"
      style={{
        background:
          "linear-gradient(135deg, var(--maroon) 0%, var(--maroon-mid) 100%)",
      }}
    >
      <div className="marquee-track">
        {doubled.map((img, i) => (
          <div
            key={`${img.label}-${i}`}
            className="flex-shrink-0 mr-3"
            style={{
              width: 220,
              height: 154,
              borderRadius: 10,
              overflow: "hidden",
              position: "relative",
            }}
          >
            <img
              src={img.url}
              alt={img.label}
              loading="lazy"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
            <div
              style={{
                position: "absolute",
                bottom: 0,
                left: 0,
                right: 0,
                background: "linear-gradient(transparent, rgba(0,0,0,0.72))",
                color: "white",
                fontSize: "0.75rem",
                fontWeight: 600,
                padding: "0.4rem 0.65rem",
              }}
            >
              {img.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── HERO SLIDESHOW ──────────────────────────────────────────────────────────

function HeroSlideshow() {
  const [current, setCurrent] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const go = useCallback((n: number) => {
    setCurrent((HERO_SLIDES.length + n) % HERO_SLIDES.length);
  }, []);

  const resetTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setCurrent((c) => (c + 1) % HERO_SLIDES.length);
    }, 5000);
  }, []);

  useEffect(() => {
    resetTimer();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [resetTimer]);

  const handlePrev = () => {
    go(current - 1);
    resetTimer();
  };
  const handleNext = () => {
    go(current + 1);
    resetTimer();
  };
  const handleDot = (i: number) => {
    setCurrent(i);
    resetTimer();
  };

  return (
    <div
      id="home"
      style={{
        position: "relative",
        overflow: "hidden",
        height: "65vh",
        minHeight: 340,
      }}
    >
      {HERO_SLIDES.map((slide, i) => (
        <div
          key={slide.tag}
          className={`icads-slide ${i === current ? "active" : ""}`}
        >
          <img
            src={slide.url}
            alt={slide.title}
            loading={i === 0 ? "eager" : "lazy"}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: "rgba(0,18,55,0.54)",
            }}
          />
          <div
            style={{
              position: "absolute",
              bottom: "18%",
              left: "7%",
              maxWidth: 580,
              color: "white",
            }}
          >
            <span
              style={{
                display: "inline-block",
                fontSize: "0.7rem",
                fontWeight: 700,
                padding: "0.18rem 0.8rem",
                borderRadius: 999,
                background: "var(--gold)",
                color: "var(--maroon-dark)",
                marginBottom: "0.65rem",
              }}
            >
              {slide.tag}
            </span>
            <h2
              style={{
                fontSize: "clamp(1.5rem, 4vw, 2.6rem)",
                fontWeight: 800,
                lineHeight: 1.2,
                marginBottom: "0.45rem",
              }}
            >
              {slide.title}
            </h2>
            <p style={{ fontSize: "clamp(0.88rem, 2vw, 1rem)", opacity: 0.9 }}>
              {slide.subtitle}
            </p>
          </div>
        </div>
      ))}

      {/* Prev/Next arrows */}
      <button
        type="button"
        onClick={handlePrev}
        aria-label="Previous slide"
        data-ocid="hero.pagination_prev"
        style={{
          position: "absolute",
          top: "50%",
          left: "1rem",
          transform: "translateY(-50%)",
          width: 40,
          height: 40,
          borderRadius: "50%",
          background: "rgba(0,33,80,0.7)",
          border: "none",
          color: "white",
          fontSize: "1rem",
          zIndex: 10,
          cursor: "pointer",
          backdropFilter: "blur(4px)",
        }}
      >
        &#10094;
      </button>
      <button
        type="button"
        onClick={handleNext}
        aria-label="Next slide"
        data-ocid="hero.pagination_next"
        style={{
          position: "absolute",
          top: "50%",
          right: "1rem",
          transform: "translateY(-50%)",
          width: 40,
          height: 40,
          borderRadius: "50%",
          background: "rgba(0,33,80,0.7)",
          border: "none",
          color: "white",
          fontSize: "1rem",
          zIndex: 10,
          cursor: "pointer",
          backdropFilter: "blur(4px)",
        }}
      >
        &#10095;
      </button>

      {/* Dots */}
      <div
        style={{
          position: "absolute",
          bottom: "1.25rem",
          left: 0,
          right: 0,
          display: "flex",
          justifyContent: "center",
          gap: 8,
          zIndex: 10,
        }}
      >
        {HERO_SLIDES.map((slide, i) => (
          <button
            type="button"
            key={slide.tag}
            className={`slide-dot ${i === current ? "active" : ""}`}
            onClick={() => handleDot(i)}
            aria-label={`Go to slide ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}

// ─── STATS STRIP ─────────────────────────────────────────────────────────────

function StatsStrip() {
  return (
    <div
      id="stats-strip"
      style={{ backgroundColor: "var(--maroon)", padding: "2.5rem 1rem" }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
          gap: "1.5rem",
          maxWidth: 900,
          margin: "0 auto",
        }}
      >
        {[
          { target: 800, suffix: "+", label: "Students Enrolled" },
          { target: 120, suffix: "+", label: "Research Publications" },
          { target: 50, suffix: "+", label: "Faculty Members" },
          { target: 95, suffix: "%", label: "Placement Rate" },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <div
              className="stat-number text-4xl font-extrabold"
              style={{ color: "var(--gold)" }}
              data-target={s.target}
              data-suffix={s.suffix}
            >
              0{s.suffix}
            </div>
            <div
              className="text-xs mt-1"
              style={{ color: "var(--gold-light)" }}
            >
              {s.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── CONFERENCE CHAIR ────────────────────────────────────────────────────────

function ChairMessage() {
  return (
    <Section>
      <div className="max-w-4xl mx-auto reveal">
        <SectionLabel>Leadership</SectionLabel>
        <SectionHeading>Message from the Conference Chair</SectionHeading>
        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="flex flex-col items-center flex-shrink-0">
            <img
              src="https://randomuser.me/api/portraits/men/75.jpg"
              alt="Dr. Ashutosh Kumar Singh"
              style={{
                width: 136,
                height: 136,
                borderRadius: "50%",
                objectFit: "cover",
                border: "4px solid var(--gold)",
                boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
              }}
            />
            <p
              className="font-bold text-sm mt-3 text-center"
              style={{ color: "var(--maroon)" }}
            >
              Dr. Ashutosh Kumar Singh
            </p>
            <span
              className="text-[0.68rem] font-semibold px-3 py-1 rounded-full mt-1"
              style={{ background: "var(--page-bg)", color: "var(--maroon)" }}
            >
              Conference Chair
            </span>
            <p
              className="text-[0.7rem] mt-1"
              style={{ color: "var(--text-light)" }}
            >
              IIIT Bhopal
            </p>
          </div>
          <div className="flex-1 relative">
            <div
              style={{
                position: "absolute",
                top: "-1rem",
                left: "-0.5rem",
                fontSize: "5rem",
                opacity: 0.1,
                color: "var(--maroon)",
                lineHeight: 1,
                fontFamily: "Georgia, serif",
                pointerEvents: "none",
                userSelect: "none",
              }}
            >
              &ldquo;
            </div>
            <p
              className="text-sm leading-relaxed mb-3 relative z-10"
              style={{ color: "#4b5563" }}
            >
              It gives me immense pleasure to welcome you to the International
              Conference on Artificial Intelligence and Data Science (ICADS
              2025), hosted at the Indian Institute of Information Technology,
              Bhopal. This conference serves as a premier platform for
              researchers, academicians, and industry professionals to share
              cutting-edge advances in AI, machine learning, and data-driven
              technologies.
            </p>
            <p
              className="text-sm leading-relaxed mb-3 relative z-10"
              style={{ color: "#4b5563" }}
            >
              Our commitment to excellence in research and innovation drives us
              to bring together brilliant minds from across the globe. I invite
              you to participate actively in the workshops, paper presentations,
              and keynote sessions that will spark new collaborations and
              inspire future breakthroughs. Together, we will shape the future
              of intelligent systems.
            </p>
            <p
              className="italic text-[0.82rem] font-semibold border-t pt-3 mt-2"
              style={{ color: "var(--maroon)", borderColor: "#e5e7eb" }}
            >
              — Dr. Ashutosh Kumar Singh, Conference Chair, ICADS 2025
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

// ─── COMMITTEE ───────────────────────────────────────────────────────────────

function CommitteeSection() {
  return (
    <Section id="committee" light>
      <div className="max-w-5xl mx-auto reveal">
        <SectionLabel>Organization</SectionLabel>
        <SectionHeading>Conference Committee</SectionHeading>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {COMMITTEE.map((m, i) => (
            <div
              key={m.name}
              className="bg-white rounded-lg border text-center p-5"
              style={{
                borderColor: "var(--border-color)",
                boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              }}
              data-ocid={`committee.item.${i + 1}`}
            >
              <img
                src={m.photo}
                alt={m.name}
                style={{
                  width: 76,
                  height: 76,
                  borderRadius: "50%",
                  objectFit: "cover",
                  margin: "0 auto 0.6rem",
                  border: "3px solid var(--maroon)",
                }}
              />
              <p
                className="font-bold text-[0.84rem]"
                style={{ color: "var(--maroon)" }}
              >
                {m.name}
              </p>
              <span
                className="inline-block text-[0.68rem] px-2 py-0.5 rounded-full mt-1.5 mb-1 font-semibold"
                style={{ background: "var(--maroon)", color: "white" }}
              >
                {m.role}
              </span>
              <p
                className="text-[0.7rem]"
                style={{ color: "var(--text-light)" }}
              >
                {m.inst}
              </p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ─── IMPORTANT DATES ─────────────────────────────────────────────────────────

function ImportantDates() {
  return (
    <Section id="important-dates">
      <div className="max-w-2xl mx-auto reveal">
        <SectionLabel>Timeline</SectionLabel>
        <SectionHeading>Important Dates</SectionHeading>
        <div className="space-y-3">
          {DATES.map((d, i) => (
            <div
              key={d.date}
              className="flex items-center gap-3 p-3.5 rounded-lg"
              style={{
                background: "var(--page-bg)",
                borderLeft: "4px solid var(--maroon)",
              }}
              data-ocid={`dates.item.${i + 1}`}
            >
              <span className="text-xl flex-shrink-0">{d.icon}</span>
              <div>
                <p
                  className="font-bold text-[0.84rem]"
                  style={{ color: "var(--maroon)" }}
                >
                  {d.date}
                </p>
                <p className="text-[0.83rem]" style={{ color: "#4b5563" }}>
                  {d.event}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ─── KEYNOTE SPEAKERS ────────────────────────────────────────────────────────

function SpeakersSection() {
  return (
    <Section id="speakers" light>
      <div className="max-w-5xl mx-auto reveal">
        <SectionLabel>Invited Talks</SectionLabel>
        <SectionHeading>Keynote Speakers</SectionHeading>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {SPEAKERS.map((s, i) => (
            <div
              key={s.name}
              className="bg-white rounded-lg border p-4 flex gap-3 items-start"
              style={{
                borderColor: "var(--border-color)",
                boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              }}
              data-ocid={`speakers.item.${i + 1}`}
            >
              <img
                src={s.photo}
                alt={s.name}
                style={{
                  width: 60,
                  height: 60,
                  borderRadius: "50%",
                  objectFit: "cover",
                  flexShrink: 0,
                  border: "3px solid var(--gold)",
                }}
              />
              <div>
                <p
                  className="font-bold text-[0.88rem]"
                  style={{ color: "var(--maroon)" }}
                >
                  {s.name}
                </p>
                <p
                  className="text-[0.7rem] mb-1.5"
                  style={{ color: "var(--text-light)" }}
                >
                  {s.inst}
                </p>
                <p
                  className="text-[0.83rem] italic"
                  style={{ color: "#4b5563" }}
                >
                  &ldquo;{s.talk}&rdquo;
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ─── WORKSHOPS ───────────────────────────────────────────────────────────────

function WorkshopsSection() {
  return (
    <Section id="workshop">
      <div className="max-w-5xl mx-auto reveal">
        <SectionLabel>Pre-Conference</SectionLabel>
        <SectionHeading>Workshops</SectionHeading>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {WORKSHOPS.map((w, i) => (
            <div
              key={w.title}
              className="rounded-lg border p-5"
              style={{
                background: "var(--page-bg)",
                borderColor: "var(--border-color)",
              }}
              data-ocid={`workshops.item.${i + 1}`}
            >
              <h3
                className="font-bold text-[0.94rem] mb-2"
                style={{ color: "var(--maroon)" }}
              >
                {w.title}
              </h3>
              <p className="text-[0.83rem] mb-3" style={{ color: "#4b5563" }}>
                {w.desc}
              </p>
              <span
                className="inline-block text-[0.7rem] px-2 py-0.5 rounded-full font-semibold mr-1.5"
                style={{ background: "var(--maroon)", color: "white" }}
              >
                📅 {w.date}
              </span>
              <span
                className="inline-block text-[0.7rem] px-2 py-0.5 rounded-full font-semibold"
                style={{
                  background: "var(--gold)",
                  color: "var(--maroon-dark)",
                }}
              >
                ⏱ {w.dur}
              </span>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ─── PAPER SUBMISSION ────────────────────────────────────────────────────────

function SubmissionSection() {
  return (
    <Section id="submission" light>
      <div className="max-w-5xl mx-auto reveal">
        <SectionLabel>Guidelines</SectionLabel>
        <SectionHeading>Paper Submission</SectionHeading>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.5rem",
          }}
        >
          {/* Topics */}
          <div
            className="bg-white rounded-lg border p-5"
            style={{
              borderColor: "var(--border-color)",
              boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
            }}
          >
            <h3
              className="font-bold text-[0.94rem] mb-3"
              style={{ color: "var(--maroon)" }}
            >
              Topics of Interest
            </h3>
            {TOPICS.map((t) => (
              <div
                key={t}
                className="flex gap-2 text-[0.83rem] mb-1.5"
                style={{ color: "#4b5563" }}
              >
                <span style={{ color: "var(--gold)" }}>▸</span>
                <span>{t}</span>
              </div>
            ))}
          </div>

          {/* Right column */}
          <div className="space-y-4">
            <div
              className="bg-white rounded-lg border p-5"
              style={{
                borderColor: "var(--border-color)",
                boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              }}
            >
              <h3
                className="font-bold text-[0.88rem] mb-2.5"
                style={{ color: "var(--maroon)" }}
              >
                Formatting Requirements
              </h3>
              {[
                "IEEE double-column format",
                "6–8 pages (including references)",
                "PDF format only",
                "Blind review — no author information",
              ].map((r) => (
                <p
                  key={r}
                  className="text-[0.82rem] mb-1.5"
                  style={{ color: "#4b5563" }}
                >
                  • {r}
                </p>
              ))}
            </div>
            <div
              className="bg-white rounded-lg border p-5"
              style={{
                borderColor: "var(--border-color)",
                boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              }}
            >
              <h3
                className="font-bold text-[0.88rem] mb-2.5"
                style={{ color: "var(--maroon)" }}
              >
                Submission Steps
              </h3>
              {[
                "Register on EasyChair portal",
                "Prepare paper in IEEE format",
                "Submit PDF via EasyChair",
                "Await review notification",
              ].map((s, i) => (
                <p
                  key={s}
                  className="text-[0.82rem] mb-1.5"
                  style={{ color: "#4b5563" }}
                >
                  {i + 1}. {s}
                </p>
              ))}
            </div>
            <button
              type="button"
              className="btn-maroon w-full"
              onClick={() => alert("EasyChair portal link coming soon!")}
              data-ocid="submission.submit.button"
            >
              🚀 Submit Paper via EasyChair
            </button>
          </div>
        </div>
      </div>
    </Section>
  );
}

// ─── SPECIAL SESSIONS ────────────────────────────────────────────────────────

function SpecialSessionsSection() {
  return (
    <Section id="special-session">
      <div className="max-w-5xl mx-auto reveal">
        <SectionLabel>Tracks</SectionLabel>
        <SectionHeading>Special Sessions</SectionHeading>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {SPECIALS.map((s, i) => (
            <div
              key={s.title}
              className="rounded-lg border p-5"
              style={{
                background: "var(--page-bg)",
                borderColor: "var(--border-color)",
              }}
              data-ocid={`specials.item.${i + 1}`}
            >
              <div className="text-3xl mb-2.5">{s.icon}</div>
              <h3
                className="font-bold text-[0.92rem] mb-1.5"
                style={{ color: "var(--maroon)" }}
              >
                {s.title}
              </h3>
              <p className="text-[0.83rem]" style={{ color: "#4b5563" }}>
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ─── REGISTRATION ────────────────────────────────────────────────────────────

function RegistrationSection() {
  return (
    <Section id="registration" light>
      <div className="max-w-4xl mx-auto reveal">
        <SectionLabel>Fees</SectionLabel>
        <SectionHeading>Registration</SectionHeading>
        <div
          className="overflow-x-auto rounded-xl border"
          style={{ borderColor: "var(--border-color)" }}
        >
          <table className="reg-table">
            <thead>
              <tr>
                <th style={{ textAlign: "left" }}>Category</th>
                <th>
                  Early Bird
                  <br />
                  <small style={{ opacity: 0.75 }}>(by 31 Jul)</small>
                </th>
                <th>Regular</th>
                <th>Student</th>
              </tr>
            </thead>
            <tbody>
              {[
                {
                  cat: "Academic Author",
                  eb: "₹5,000",
                  reg: "₹6,500",
                  stu: "₹3,500",
                },
                {
                  cat: "Industry Professional",
                  eb: "₹8,000",
                  reg: "₹10,000",
                  stu: "—",
                },
                {
                  cat: "International Author",
                  eb: "$200",
                  reg: "$250",
                  stu: "$120",
                },
                {
                  cat: "Attendee Only",
                  eb: "₹2,000",
                  reg: "₹3,000",
                  stu: "₹1,000",
                },
              ].map((r, i) => (
                <tr key={r.cat} data-ocid={`registration.row.${i + 1}`}>
                  <td>{r.cat}</td>
                  <td className="reg-table-green">{r.eb}</td>
                  <td>{r.reg}</td>
                  <td>{r.stu}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="text-center mt-6">
          <button
            type="button"
            className="btn-gold"
            onClick={() => alert("Registration portal opening soon!")}
            data-ocid="registration.register.button"
          >
            Register Now
          </button>
        </div>
      </div>
    </Section>
  );
}

// ─── SPONSORSHIP ─────────────────────────────────────────────────────────────

function SponsorshipSection() {
  return (
    <Section id="sponsorship">
      <div className="max-w-5xl mx-auto reveal">
        <SectionLabel>Partnership</SectionLabel>
        <SectionHeading>Sponsorship Opportunities</SectionHeading>

        {/* Tier cards */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: "1.25rem",
            marginBottom: "2.5rem",
          }}
        >
          {TIERS.map((t, i) => (
            <div
              key={t.tier}
              className="rounded-xl p-5 text-center"
              style={{
                background: "var(--page-bg)",
                border: `2px solid ${t.color}`,
                transition: "box-shadow 0.2s, transform 0.2s",
              }}
              data-ocid={`sponsorship.item.${i + 1}`}
            >
              <div className="text-4xl mb-1.5">🏆</div>
              <div
                className="text-lg font-extrabold"
                style={{ color: t.color }}
              >
                {t.tier} Sponsor
              </div>
              <div
                className="text-xl font-extrabold mt-1 mb-3"
                style={{ color: "var(--maroon)" }}
              >
                {t.price}
              </div>
              {t.benefits.map((b) => (
                <div
                  key={b}
                  className="flex gap-2 text-[0.8rem] text-left mb-1.5"
                  style={{ color: "#4b5563" }}
                >
                  <span style={{ color: t.color, flexShrink: 0 }}>✓</span>
                  <span>{b}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Current Sponsors */}
        <h3
          className="text-base font-bold text-center mb-4"
          style={{ color: "var(--maroon)" }}
        >
          Current Sponsors &amp; Partners
        </h3>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(100px, 1fr))",
            gap: "0.65rem",
          }}
        >
          {SPONSORS.map((s) => (
            <div
              key={s}
              className="py-2 px-2 rounded-lg text-center text-[0.75rem] font-bold border"
              style={{
                color: "var(--maroon)",
                background: "var(--page-bg)",
                borderColor: "var(--border-color)",
              }}
            >
              {s}
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

// ─── CONTACT ─────────────────────────────────────────────────────────────────

function ContactSection() {
  return (
    <Section id="contact" light>
      <div className="max-w-4xl mx-auto reveal">
        <SectionLabel>Get in Touch</SectionLabel>
        <SectionHeading>Contact Us</SectionHeading>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "1.5rem",
          }}
        >
          {/* Contact info */}
          <div className="space-y-3">
            {[
              {
                icon: "📍",
                label: "Address",
                value:
                  "Room No TB-201, NTB, MANIT Campus, Bhopal, Madhya Pradesh — 462003",
              },
              { icon: "📞", label: "Phone", value: "0755-2900140" },
              { icon: "✉️", label: "Email", value: "info@iiitbhopal.ac.in" },
              { icon: "🌐", label: "Website", value: "www.iiitbhopal.ac.in" },
            ].map((c) => (
              <div
                key={c.label}
                className="flex gap-3 p-3 rounded-lg bg-white border"
                style={{
                  borderColor: "var(--border-color)",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
                }}
              >
                <span className="text-xl flex-shrink-0">{c.icon}</span>
                <div>
                  <p
                    className="text-[0.66rem] font-bold uppercase tracking-widest"
                    style={{ color: "var(--gold)" }}
                  >
                    {c.label}
                  </p>
                  <p className="text-[0.83rem]" style={{ color: "#4b5563" }}>
                    {c.value}
                  </p>
                </div>
              </div>
            ))}
            <div
              className="p-3 rounded-lg bg-white border"
              style={{ borderColor: "var(--border-color)" }}
            >
              <p
                className="text-[0.66rem] font-bold uppercase tracking-widest mb-2"
                style={{ color: "var(--gold)" }}
              >
                Follow Us
              </p>
              {["Facebook", "Twitter", "Instagram", "LinkedIn"].map((s) => (
                <button type="button" key={s} className="social-pill">
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Map placeholder */}
          <div
            className="rounded-xl flex items-center justify-center min-h-[260px] text-white text-center p-6"
            style={{ background: "var(--maroon)" }}
          >
            <div>
              <div className="text-5xl mb-3">🗺️</div>
              <p className="font-bold text-lg">MANIT Campus, Bhopal</p>
              <p className="text-sm opacity-75 mt-1">
                Madhya Pradesh, India — 462003
              </p>
              <a
                href="https://maps.google.com/?q=MANIT+Bhopal"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-gold inline-block mt-4 text-xs px-5 py-2 rounded-full"
                data-ocid="contact.map.link"
              >
                Open in Maps
              </a>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}

// ─── FOOTER ──────────────────────────────────────────────────────────────────

function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer
      style={{
        backgroundColor: "var(--maroon)",
        color: "white",
        padding: "3rem 1rem 1.5rem",
      }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
          gap: "2rem",
          maxWidth: 1100,
          margin: "0 auto 2rem",
        }}
      >
        <div>
          <h4
            className="font-bold text-[0.84rem] mb-3"
            style={{ color: "var(--gold)" }}
          >
            Contact Us
          </h4>
          <a href="mailto:info@iiitbhopal.ac.in" className="footer-link">
            info@iiitbhopal.ac.in
          </a>
          <a href="tel:07552900140" className="footer-link">
            0755-2900140
          </a>
          <span className="footer-link">Room TB-201, NTB</span>
          <span className="footer-link">MANIT Campus, Bhopal</span>
        </div>
        <div>
          <h4
            className="font-bold text-[0.84rem] mb-3"
            style={{ color: "var(--gold)" }}
          >
            Important Links
          </h4>
          {[
            "Scholarship",
            "T&P Cell",
            "UG / PG Programme",
            "Admission",
            "Anti-Ragging",
          ].map((l) => (
            <button
              type="button"
              key={l}
              className="footer-link"
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                textAlign: "left",
                width: "100%",
                padding: 0,
              }}
            >
              {l}
            </button>
          ))}
        </div>
        <div>
          <h4
            className="font-bold text-[0.84rem] mb-3"
            style={{ color: "var(--gold)" }}
          >
            Useful Links
          </h4>
          {[
            "Notice Board",
            "Vision & Mission",
            "Research",
            "ERP Portal",
            "Contact Us",
          ].map((l) => (
            <button
              type="button"
              key={l}
              className="footer-link"
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                textAlign: "left",
                width: "100%",
                padding: 0,
              }}
            >
              {l}
            </button>
          ))}
        </div>
        <div>
          <h4
            className="font-bold text-[0.84rem] mb-3"
            style={{ color: "var(--gold)" }}
          >
            Follow Us
          </h4>
          {["Facebook", "Twitter", "Instagram", "LinkedIn", "YouTube"].map(
            (l) => (
              <button
                type="button"
                key={l}
                className="footer-link"
                style={{
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  textAlign: "left",
                  width: "100%",
                  padding: 0,
                }}
              >
                {l}
              </button>
            ),
          )}
        </div>
      </div>
      <div
        className="text-center text-[0.7rem]"
        style={{
          opacity: 0.55,
          borderTop: "1px solid #a52a2a",
          paddingTop: "1rem",
        }}
      >
        © {year} IIIT Bhopal. All Rights Reserved. &nbsp;|&nbsp; Built with ❤️
        using{" "}
        <a
          href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
          target="_blank"
          rel="noopener noreferrer"
          style={{ textDecoration: "underline", opacity: 0.85 }}
        >
          caffeine.ai
        </a>
      </div>
    </footer>
  );
}

// ─── SCROLL TO TOP FAB ───────────────────────────────────────────────────────

function ScrollToTopFab() {
  const show = useScrollTop();
  return (
    <button
      type="button"
      id="btn-scroll-top"
      className={show ? "show" : ""}
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="Scroll to top"
      data-ocid="page.scroll_top.button"
    >
      ↑
    </button>
  );
}

// ─── APP ROOT ────────────────────────────────────────────────────────────────

export default function App() {
  useScrollReveal();
  useStatsCounter();
  const activeId = useActiveSection();

  return (
    <div style={{ fontFamily: "'Poppins', sans-serif" }}>
      <InstituteHeader />
      <TickerBar />
      <StickyNav activeId={activeId} />
      <MarqueeStrip />
      <HeroSlideshow />
      <StatsStrip />
      <ChairMessage />
      <CommitteeSection />
      <ImportantDates />
      <SpeakersSection />
      <WorkshopsSection />
      <SubmissionSection />
      <SpecialSessionsSection />
      <RegistrationSection />
      <SponsorshipSection />
      <ContactSection />
      <Footer />
      <ScrollToTopFab />
    </div>
  );
}
